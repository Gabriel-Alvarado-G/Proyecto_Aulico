<?php
include("config.php");
session_start(); 

$id_usuario = isset($_SESSION["id_usuario"]) ? $_SESSION["id_usuario"] : null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $id_obra = intval($_POST["id_obra"]);
    $nombre_obra = htmlspecialchars(trim($_POST["nombre_obra"]));
    $estado = htmlspecialchars(trim($_POST["estado"]));
    $gasto_valor = intval($_POST["gasto_valor"]);

    // Actualizar los campos en la tabla Obras
    $stmt_obras = $mysqli->prepare("UPDATE obras SET nombre_obra = ?, estado = ? WHERE id_obras = ?");
    $stmt_obras->bind_param("ssi", $nombre_obra, $estado, $id_obra);
    $stmt_obras->execute();
    $stmt_obras->close();

    // Actualizar los campos en la tabla Gastos
    $stmt_gastos = $mysqli->prepare("UPDATE gastos SET valor = ? WHERE id_obras = ?");
    $stmt_gastos->bind_param("ii", $gasto_valor, $id_obra);
    $stmt_gastos->execute();
    $stmt_gastos->close();

    // Función para procesar la actualización del archivo (si se proporciona)
    function procesarArchivo($campo, $tipo, $id_obra) {
        global $mysqli; // Agrega esta línea para poder acceder a $mysqli dentro de la función

        if ($_FILES[$campo]["error"] == UPLOAD_ERR_OK) {
            $nombre_temporal = $_FILES[$campo]["tmp_name"];
            $nombre_archivo = $_FILES[$campo]["name"];
            $ruta_destino = "docs/" . $nombre_archivo;

            if (!move_uploaded_file($nombre_temporal, $ruta_destino)) {
                die('Error al mover el archivo cargado.');
            }

            $stmt = $mysqli->prepare("UPDATE $tipo SET ruta_archivo = ? WHERE id_obras = ?");
            $stmt->bind_param("si", $ruta_destino, $id_obra);
            $stmt->execute();
            $stmt->close();
        }
    }

    // Llamar a la función para procesar los archivos según sea necesario
    procesarArchivo("material_ruta_archivo", "materiales", $id_obra);
    procesarArchivo("plano_ruta_archivo", "planos", $id_obra);
    procesarArchivo("avance_ruta_archivo", "avances", $id_obra);

    header("Location: pagArquitecto.php?success=true");
    exit();
} else {
    header("Location: pagArquitecto.php");
    exit();
}
?>
