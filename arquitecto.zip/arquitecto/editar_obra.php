<?php
include("config.php");
session_start(); 

$id_usuario = isset($_SESSION["id_usuario"]) ? $_SESSION["id_usuario"] : null;

// Obtener el ID de la obra a editar
$id_obra = $_GET['id'];

// Consulta para obtener los datos de la obra y sus asociaciones
$sql = "SELECT obras.nombre_obra, obras.estado, 
               materiales.id_materiales, materiales.ruta_archivo AS material_ruta_archivo,
               planos.id_planos, planos.ruta_archivo AS plano_ruta_archivo,
               gastos.id_gastos, gastos.valor AS gasto_valor,
               avances.id_avance, avances.ruta_archivo AS avance_ruta_archivo
        FROM obras
        LEFT JOIN materiales ON obras.id_obras = materiales.id_obras
        LEFT JOIN planos ON obras.id_obras = planos.id_obras
        LEFT JOIN gastos ON obras.id_obras = gastos.id_obras
        LEFT JOIN avances ON obras.id_obras = avances.id_obras
        WHERE obras.id_obras = $id_obra";

$result = $mysqli->query($sql);
$row = $result->fetch_assoc();

// Liberar el resultado
$result->free();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Obra</title>
    <link rel="stylesheet" href="css/mystyle1.css">
</head>
<body>
    
    <div class="formulario-obras">
        <h2 class="texto-secundario">Editar Obra</h2>

        <form action="procesar_editar_obra.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_obra" value="<?php echo $id_obra; ?>">

            <label for="nombre_obra">Nombre de la Obra:</label><br>
            <input type="text" id="nombre_obra" name="nombre_obra" value="<?php echo $row['nombre_obra']; ?>" required><br>

            <label for="estado">Estado de la Obra:</label><br>
            <select id="estado" name="estado" required>
                <option value="pendiente" <?php if ($row['estado'] == 'pendiente') echo 'selected'; ?>>Pendiente</option>
                <option value="en_proceso" <?php if ($row['estado'] == 'en_proceso') echo 'selected'; ?>>En Proceso</option>
                <option value="finalizada" <?php if ($row['estado'] == 'finalizada') echo 'selected'; ?>>Finalizada</option>
            </select><br><br>

            <!-- editar Materiales -->
            <label for="material_ruta_archivo">Ruta de Archivo de Materiales:</label><br>
            <input type="file" id="material_ruta_archivo" name="material_ruta_archivo"><br>

            <!-- editar Planos -->
            <label for="plano_ruta_archivo">Ruta de Archivo de Planos:</label><br>
            <input type="file" id="plano_ruta_archivo" name="plano_ruta_archivo"><br>

            <!-- editar Gastos -->
            <label for="gasto_valor">Valor del Gasto:</label><br>
            <input type="number" id="gasto_valor" name="gasto_valor" value="<?php echo $row['gasto_valor']; ?>" ><br>

            <!-- editar Avances -->
            <label for="avance_ruta_archivo">Ruta de Archivo de Avances:</label><br>
            <input type="file" id="avance_ruta_archivo" name="avance_ruta_archivo"><br><br>

            <div class="boton">
                <button type="submit">Guardar Cambios</button>
            </div>
        </form>
    </div>
</body>
</html>
