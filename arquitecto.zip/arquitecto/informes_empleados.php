<?php
include("config.php");
session_start(); 

if (!isset($_SESSION["id_usuario"])) {
    echo "SESION CADUCADA.";
    exit;
}

$id_usuario = $_SESSION["id_usuario"];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informes</title>
    <link rel="stylesheet" href="css/mystyle1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/3fa31e8dc6.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="icon-bar">
        <a href="pagEmpleado.php"><i class="fa fa-home"></i></a>
        <a href="informes_empleados.php"><i class="fa-solid fa-file-circle-plus"></i></a>
        <a href="tabla_empleado.php"><i class="fa-solid fa-table-cells"></i></a>
        <a href="salir.php"><i class="fa-solid fa-right-from-bracket"></i></a>
    </div>

    <div class="formulario-obras">
        <h2 class="texto-secundario">Registrar Nuevo Informe</h2>
        <form action="procesar_informe.php" method="POST" enctype="multipart/form-data">
            <label for="informe">Titulo del informe:</label><br>
            <input type="text" id="informe" name="informe" required><br>

            <label for="archivo">Subir informe: </label> <br>
            <input type="file" id="archivo" name="archivo" required> <br>

            <label for="horas">Horas trabajadas:</label><br>
            <input type="time" id="horas" name="horas" required><br>


            <label for="id_obras">Seleccionar Obra:</label><br>
            <select id="id_obras" name="id_obras" required>
            <?php
                $query = "SELECT obras.id_obras, obras.nombre_obra 
                        FROM obras 
                        INNER JOIN asignacion_empleados_obras ON obras.id_obras = asignacion_empleados_obras.id_obras
                        WHERE asignacion_empleados_obras.id_empleado = $id_usuario
                        AND obras.eliminar = 'pendiente'";
                $result = $mysqli->query($query);
                if (!$result) {
                    die('Error en la consulta SQL: ' . $mysqli->error);
                }
                while($row = $result->fetch_assoc()) {
                    echo "<option value=\"{$row['id_obras']}\">{$row['nombre_obra']}</option>";
                }

                $result->free();
             ?>
            </select><br>

            <div class="boton">
                <button type="submit">Subir Informe</button>
            </div>
        </form>
    </div>
</body>
</html>
