<?php
include("config.php");
session_start(); 

if (!isset($_SESSION["id_usuario"])) {
    echo "SESION CADUCADA.";
    exit;
}

$id_usuario = $_SESSION["id_usuario"];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arquitecto</title>
    <link rel="stylesheet" href="css/mystyle1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/3fa31e8dc6.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="icon-bar">
    <a href="pagArquitecto.php"><i class="fa fa-home"></i></a>
    <a href="obras.php"><i class="fa-solid fa-calendar-days"></i></a>
    <a href="materiales.php"><i class="fa-solid fa-trowel-bricks"></i></a>
    <a href="planos.php"><i class="fa-solid fa-paste"></i></a>
    <a href="gastos.php"><i class="fa-solid fa-coins"></i></a>
    <a href="avances.php"><i class="fa-solid fa-check"></i></a>
    <a href="mis_empleados.php"><i class="fa-solid fa-table-cells"></i></a>
    <a href="salir.php"><i class="fa-solid fa-right-from-bracket"></i></a>


</div>
    
    <div class="formulario-obras">
        <h2 class="texto-secundario">Subir Nuevas Obras</h2>
        
        <form action="nuevaObra.php" method="POST">
            <label for="nombre_obra">Nombre de la Obra:</label><br>
            <input type="text" id="nombre_obra" name="nombre_obra" required><br>
            
            <label for="direccion">Dirección:</label><br>
            <input type="text" id="direccion" name="direccion" required><br>
            
            <label for="fecha_inicio">Fecha de Inicio:</label><br>
            <input type="date" id="fecha_inicio" name="fecha_inicio" required><br>
            
            <label for="fecha_fin">Fecha de Fin:</label><br>
            <input type="date" id="fecha_fin" name="fecha_fin" required><br>
            
            <label for="estado">Estado:</label><br>
            <select id="estado" name="estado" required>
                <option value="pendiente">Pendiente</option>
                <option value="en_proceso">En proceso</option>
                <option value="finalizada">Finalizada</option>
            </select><br>

            <label for="id_empleado">Seleccionar Empleado:</label><br>
            <select id="id_empleado" name="id_empleado" required>
                    <?php
                    $query = "SELECT id_registro, CONCAT(nombres, ' ', apellidos) AS nombre_completo FROM Registro WHERE rol = 'empleado' AND estado = 'sin'";
                    $result = $mysqli->query($query);
                
                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['id_registro'] . "'>" . $row['nombre_completo'] . "</option>";
                        }
                    } else {
                        echo "<option value='' disabled selected>No hay empleados disponibles</option>";
                    }
                    ?>
            </select><br>
            
            <!-- Agregar el campo oculto para el ID de usuario -->
            <input type="hidden" name="id_usuario" value="<?php echo $id_usuario; ?>">

            <div class="boton">
                <button type="submit">Subir Obra</button>
            </div>
        </form>
    </div>
</body>
</html>
