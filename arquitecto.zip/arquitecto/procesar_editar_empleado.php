<?php
include("config.php");
session_start();

// Verificar si se ha iniciado sesión y obtener el ID de usuario
$id_usuario = isset($_SESSION["id_usuario"]) ? $_SESSION["id_usuario"] : null;

// Verificar si se han enviado los datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $id_informe = $_POST["id_informe"];
    $titulo = $_POST["titulo"];
    $horas = !empty($_POST["horas"]) ? $_POST["horas"] : null; // Validar si se ha proporcionado un valor de horas
    
    // Verificar si se ha subido un nuevo archivo
    if ($_FILES["archivo"]["name"]) {
        // Procesar el archivo y actualizar la ruta en la base de datos
        $ruta_destino = "docs/" . basename($_FILES["archivo"]["name"]);
        if (move_uploaded_file($_FILES["archivo"]["tmp_name"], $ruta_destino)) {
            $sql = "UPDATE informes_empleados SET titulo = ?, horas = ?, ruta_archivo = ? WHERE id_informe = ?";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("sssi", $titulo, $horas, $ruta_destino, $id_informe);

            // Ejecutar la consulta preparada
            if ($stmt->execute()) {
                header("Location: tabla_empleado.php?success=true");
                exit();
            } else {
                // Imprimir consulta SQL y mensaje de error
                echo "Error al ejecutar la consulta: " . $stmt->error;
            }

            // Cerrar la conexión y liberar recursos
            $stmt->close();
        } else {
            // Imprimir mensaje de error si no se pudo mover el archivo
            echo "Error al mover el archivo.";
        }
    } else {
        // No se ha subido un nuevo archivo, actualizar solo título y horas
        $sql = "UPDATE informes_empleados SET titulo = ?, horas = ? WHERE id_informe = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("ssi", $titulo, $horas, $id_informe);

        // Ejecutar la consulta preparada
        if ($stmt->execute()) {
            header("Location: tabla_empleado.php?success=true");
            exit();
        } else {
            // Imprimir consulta SQL y mensaje de error
            echo "Error al ejecutar la consulta: " . $stmt->error;
        }

        // Cerrar la conexión y liberar recursos
        $stmt->close();
    }
} else {
    // Redireccionar a tabla_empleado.php si no se han enviado datos del formulario
    header("Location: tabla_empleado.php");
    exit();
}
?>
