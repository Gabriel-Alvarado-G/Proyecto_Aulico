<?php
include("config.php");
session_start(); 

$id_usuario = isset($_SESSION["id_usuario"]) ? $_SESSION["id_usuario"] : null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_obra = intval($_POST["id_obra"]); 
    $fecha_avance = $_POST["fecha_avance"];

    if (empty($fecha_avance) || empty($id_obra)) {
        header("Location: avances.php?error=empty_fields");
        exit();
    }

    if ($_FILES["archivo"]["error"] == UPLOAD_ERR_OK) {
        $nombre_temporal = $_FILES["archivo"]["tmp_name"];
        $nombre_archivo = $_FILES["archivo"]["name"];
        $ruta_destino = "docs/" . $nombre_archivo;

        if (!move_uploaded_file($nombre_temporal, $ruta_destino)) {
            die('Error al mover el archivo cargado.');
        }
    } else {
        die('Error al cargar el archivo.');
    }

    $query = "INSERT INTO Avances (id_obras, fecha_avance, ruta_archivo) VALUES (?, ?, ?)";
    $stmt = $mysqli->prepare($query);
    if (!$stmt) {
        die('Error en la preparación de la consulta: ' . $mysqli->error);
    }
    
    $stmt->bind_param("sss", $id_obra, $fecha_avance, $ruta_destino);
    
    if (!$stmt->execute()) {
        die('Error al ejecutar la consulta: ' . $stmt->error);
    }
    
    $stmt->close();

    header("Location: avances.php?success=true");
    exit();
} else {
    header("Location: avances.php");
    exit();
}
?>
