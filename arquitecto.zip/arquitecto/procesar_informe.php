<?php
include("config.php");
session_start();

$id_usuario = isset($_SESSION["id_usuario"]) ? $_SESSION["id_usuario"] : null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_obras = isset($_POST["id_obras"]) ? intval($_POST["id_obras"]) : null;
    $titulo = isset($_POST["informe"]) ? htmlspecialchars(trim($_POST["informe"])) : null;
    $horas = isset($_POST["horas"]) ? $_POST["horas"] : null; // Cambiado el tipo de dato a string

    if (empty($titulo) || empty($id_obras) || empty($horas)) {
        header("Location: informes_empleados.php?error=empty_fields");
        exit();
    }

    if ($_FILES["archivo"]["error"] == UPLOAD_ERR_OK) {
        $nombre_temporal = $_FILES["archivo"]["tmp_name"];
        $nombre_archivo = $_FILES["archivo"]["name"];
        $ruta_destino = "docs/" . $nombre_archivo;

        if (!move_uploaded_file($nombre_temporal, $ruta_destino)) {
            die('Error al mover el archivo cargado.');
        }
    } else {
        die('Error al cargar el archivo.');
    }

    $stmt_insert = $mysqli->prepare("INSERT INTO informes_empleados (titulo, horas, ruta_archivo, id_obras) VALUES (?, ?, ?, ?)");
    $stmt_insert->bind_param("sssi", $titulo, $horas, $ruta_destino, $id_obras); // Cambiado la 'i' a 's' para el tipo de dato string
    $stmt_insert->execute();
    $stmt_insert->close();

    header("Location: informes_empleados.php?success=true");
    exit();
} else {
    header("Location: informes_empleados.php");
    exit();
}
?>
