<?php
include("config.php");
session_start(); 

$id_usuario = isset($_SESSION["id_usuario"]) ? $_SESSION["id_usuario"] : null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = htmlspecialchars(trim($_POST["titulo"]));
    $id_obras = intval($_POST["id_obras"]); 

    if (empty($titulo) || empty($id_obras)) {
        header("Location: materiales.php?error=empty_fields");
        exit();
    }

    if ($_FILES["archivo"]["error"] == UPLOAD_ERR_OK) {
        $nombre_temporal = $_FILES["archivo"]["tmp_name"];
        $nombre_archivo = $_FILES["archivo"]["name"];
        $ruta_destino = "docs/" . $nombre_archivo;

        if (!move_uploaded_file($nombre_temporal, $ruta_destino)) {
            die('Error al mover el archivo cargado.');
        }
    } else {
        die('Error al cargar el archivo.');
    }

    // Verificar si ya existe un registro de materiales para la obra seleccionada
    $stmt_check = $mysqli->prepare("SELECT id_materiales FROM Materiales WHERE id_obras = ?");
    $stmt_check->bind_param("i", $id_obras);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        // si ya existe un registro de materiales para la obra, actualizar el registro existente
        $stmt_update = $mysqli->prepare("UPDATE Materiales SET titulo = ?, ruta_archivo = ? WHERE id_obras = ?");
        $stmt_update->bind_param("ssi", $titulo, $ruta_destino, $id_obras);
        $stmt_update->execute();
        $stmt_update->close();
    } else {
        // si no existe un registro de materiales para esta obra, insertar un nuevo registro
        $stmt_insert = $mysqli->prepare("INSERT INTO Materiales (titulo, ruta_archivo, id_obras) VALUES (?, ?, ?)");
        $stmt_insert->bind_param("ssi", $titulo, $ruta_destino, $id_obras);
        $stmt_insert->execute();
        $stmt_insert->close();
    }

    $stmt_check->close();

    header("Location: materiales.php?success=true");
    exit();
} else {
    header("Location: materiales.php");
    exit();
}

?>
