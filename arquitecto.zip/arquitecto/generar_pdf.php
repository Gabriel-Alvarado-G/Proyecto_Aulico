<?php
require('fpdf/fpdf.php');
include("config.php");

session_start();

if (!isset($_SESSION["id_usuario"])) {
    echo "SESION CADUCADA.";
    exit;
}

$id_usuario = $_SESSION["id_usuario"];

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial', 'B', 18); // Aumenta el tamaño y establece negrita
        $this->SetTextColor(0); // Establece el color del texto a negro

        // Agrega el título sin color de fondo
        $this->Cell(0, 10, 'Informe de Obras', 0, 0, 'C');
        $this->Ln(15); // Espaciado después del título

        $this->SetFont('Arial', 'B', 9);
        $this->SetFillColor(76, 175, 80);
        $this->SetTextColor(255);
        // Modificación de las celdas para alinear a la derecha
        $this->Cell(25, 10, 'Nombre Obra', 1, 0, 'L', 1);
        $this->Cell(30, 10, 'Estado', 1, 0, 'L', 1);
        $this->Cell(40, 10, 'Materiales', 1, 0, 'L', 1);
        $this->Cell(40, 10, 'Planos', 1, 0, 'L', 1);
        $this->Cell(25, 10, 'Gastos', 1, 0, 'L', 1);
        $this->Cell(30, 10, 'Avances', 1, 0, 'L', 1);

        $this->Ln();
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Página ' . $this->PageNo(), 0, 0, 'C');
    }

    function Row($data)
    {
        $this->SetFillColor(255);
        $this->SetTextColor(0);
        $this->SetFont('Arial', '', 8);

        // Cambios para alinear a la izquierda, al centro y añadir márgenes invisibles
        $this->Cell(25, 10, $data['nombre_obra'], 1, 0, 'L'); // Alinea a la izquierda
        $this->Cell(30, 10, $data['estado'], 1, 0, 'L'); // Alinea a la izquierda
        $this->Cell(40, 10, $data['Materiales'], 1, 0, 'L'); // Alinea a la izquierda
        $this->Cell(40, 10, $data['Planos'], 1, 0, 'L'); // Alinea a la izquierda
        $this->Cell(25, 10, '$' . $data['Gastos'], 1, 0, 'L'); // Alinea al centro
        $this->Cell(30, 10, $data['Avances'], 1, 0, 'L'); // Alinea a la izquierda
        $this->Ln();
    }
}

$pdf = new PDF();
$pdf->AddPage();

// Aquí obtenemos el ID de la obra de la URL
$id_obra = $_GET['id'];

$sql = "SELECT obras.id_obras, obras.nombre_obra, obras.estado, materiales.ruta_archivo AS Materiales,
               planos.ruta_archivo AS Planos, gastos.valor AS Gastos,
               avances.ruta_archivo AS Avances
        FROM obras
        LEFT JOIN materiales ON obras.id_obras = materiales.id_obras
        LEFT JOIN planos ON obras.id_obras = planos.id_obras
        LEFT JOIN gastos ON obras.id_obras = gastos.id_obras
        LEFT JOIN avances ON obras.id_obras = avances.id_obras
        WHERE obras.id_obras = $id_obra
        AND obras.id_registro = $id_usuario
        AND obras.eliminar = 'pendiente'";
$result = $mysqli->query($sql);

$pdf->SetFont('Arial', '', 8);

$row = $result->fetch_assoc();
$pdf->Row($row);

$pdf->Output('D', 'informe_obra_'.$id_obra.'.pdf');

$result->free();
$mysqli->close();
?>
