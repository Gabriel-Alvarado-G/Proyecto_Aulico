<?php
include("config.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/mystyle1.css">
    <title>Login</title>
</head>
<body>
<div class="login-container" id="loginContainer">
        <h2>Login</h2>
        <form id="loginForm" action="procesarLogin.php" method="POST">
            <div class="grupo-login">
                <label for="correo">Correo:</label>
                <input type="email" id="correo" name="correo" required>
            </div>
            <div class="grupo-login">
                <label for="contraseña">Contraseña:</label>
                <input type="password" id="contraseña" name="contraseña" required>
            </div>
            <div class="boton">
                <button type="submit">Iniciar</button>
            </div>

        </form>
        <div class="etiquetaA">
        <a href="#" id="mostrarRegistro">Crear cuenta</a>
        </div>
    </div>

    <div class="registro-container login-container" id="registroContainer">
        <h2>Registro</h2>
        <form id="registroForm" action="procesarRegistro.php" method="POST">
            <div class="grupo-registro">
                <label for="nombres">Nombres:</label>
                <input type="text" id="nombres" name="nombres" required>
            </div>
            <div class="grupo-registro">
                <label for="apellidos">Apellidos:</label>
                <input type="text" id="apellidos" name="apellidos" required>
            </div>
            <div class="grupo-registro">
                <label for="correo_registro">Correo electrónico:</label>
                <input type="email" id="correo_registro" name="correo_registro" required>
            </div>
            <div class="grupo-registro">
                <label for="contraseña_registro">Contraseña:</label>
                <input type="password" id="contraseña_registro" name="contraseña_registro" required>
            </div>
            <div class="boton">
                <button type="submit">Registrarse</button>
            </div>
        </form>
        <div class="etiquetaA">
            <a href="#" id="mostrarLogin">Volver al Login</a>
        </div>
    </div>

    <script>
        document.getElementById('mostrarRegistro').addEventListener('click', function(e) {
            e.preventDefault(); 
            document.getElementById('loginContainer').style.display = 'none'; 
            document.getElementById('registroContainer').style.display = 'block'; 
        });

        document.getElementById('mostrarLogin').addEventListener('click', function(e) {
            e.preventDefault(); 
            document.getElementById('registroContainer').style.display = 'none'; 
            document.getElementById('loginContainer').style.display = 'block'; 
        });

        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('registroContainer').style.display = 'none'; 
            document.getElementById('loginContainer').style.display = 'block';
        });
    </script>
    
</body>
</html>