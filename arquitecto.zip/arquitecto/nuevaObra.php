<?php
include("config.php");
session_start(); 

$id_usuario = $_SESSION["id_usuario"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($id_usuario) && is_numeric($id_usuario)) {
        $check_query = "SELECT id_registro FROM Registro WHERE id_registro = $id_usuario";
        $check_result = $mysqli->query($check_query);
    
        if ($check_result) {
            if ($check_result->num_rows == 1) {
                $nombre_obra = $_POST["nombre_obra"];
                $direccion = $_POST["direccion"];
                $fecha_inicio = $_POST["fecha_inicio"];
                $fecha_fin = $_POST["fecha_fin"];
                $estado = $_POST["estado"];
                $id_empleado = $_POST["id_empleado"];
    
                $sql = "INSERT INTO Obras (nombre_obra, direccion, fecha_inicio, fecha_fin, estado, id_registro) 
                        VALUES ('$nombre_obra', '$direccion', '$fecha_inicio', '$fecha_fin', '$estado', $id_usuario)";
    
                if ($mysqli->query($sql) === TRUE) {
                    $id_obra = $mysqli->insert_id;

                    $update_query = "UPDATE Registro SET estado = 'con' WHERE id_registro = $id_empleado";
                    if ($mysqli->query($update_query) === TRUE) {

                        $insert_asignacion_query = "INSERT INTO Asignacion_empleados_obras (id_obras, id_empleado) VALUES ($id_obra, $id_empleado)";

                        if ($mysqli->query($insert_asignacion_query) === TRUE) {
                            header("Location: obras.php?success=true");
                            exit;
                        } else {
                            echo "Error al insertar asignación: " . $mysqli->error;
                        }
                    } else {
                        echo "Error al actualizar el estado del empleado: " . $mysqli->error;
                    }
                } else {
                    // Mostrar un mensaje de error si la inserción falla
                    echo "Error al agregar la obra: " . $mysqli->error;
                }
            } else {
                echo "El ID de usuario proporcionado no existe en la tabla Registro.";
            }
        } else {
            echo "Error al verificar el ID de usuario en la tabla Registro: " . $mysqli->error;
        }
    } else {
        echo "ID de usuario no válido.";
    }
}  
?>
