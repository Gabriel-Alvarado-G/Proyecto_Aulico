<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombres = $_POST["nombres"];
    $apellidos = $_POST["apellidos"];
    $correo = $_POST["correo_registro"];
    $contraseña = $_POST["contraseña_registro"];

    if (empty($nombres) || empty($apellidos) || empty($correo) || empty($contraseña)) {
        echo "Por favor, completa todos los campos del formulario.";
    } else {
        include("config.php");

        $sql = "INSERT INTO registro (nombres, apellidos, correo_electronico, contraseña) VALUES ('$nombres', '$apellidos', '$correo', '$contraseña')";

        if ($mysqli->query($sql) === TRUE) {
            header("Location: login.php");
        } else {
            echo "Error al registrar el usuario: " . $mysqli->error;
        }
    }
} else {
    header("Location: registro.php");
    exit;
}
?>
