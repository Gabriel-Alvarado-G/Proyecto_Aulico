<?php
session_start();
require 'config.php';

if (isset($_SESSION["id_usuario"])) {
    if (isset($_GET['id']) && is_numeric($_GET['id'])) {
        $id_usuario = $_SESSION["id_usuario"];
        $id_informe = $_GET['id'];

        // Consulta para obtener los datos del informe
        $sql = "SELECT 
                    o.nombre_obra,
                    i.titulo,
                    i.ruta_archivo AS informe,
                    i.horas
                FROM obras o
                LEFT JOIN asignacion_empleados_obras a ON o.id_obras = a.id_obras
                LEFT JOIN informes_empleados i ON o.id_obras = i.id_obras
                WHERE a.id_empleado = $id_usuario 
                AND i.id_informe = $id_informe 
                AND i.eliminar = 'pendiente'";
        $result = $mysqli->query($sql);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();

            // Crear el PDF
            require('fpdf/fpdf.php');

            class PDF extends FPDF
            {
                function Header()
                {
                    $this->SetFont('Arial', 'B', 12);
                    $this->SetFillColor(76, 175, 80); // Color verde
                    $this->SetTextColor(0); // Color negro
                    $this->Cell(190, 10, 'Informe de Trabajo', 0, 1, 'C');
                    $this->SetTextColor(255, 255, 255); // Color blanco para el texto
                    $this->Ln(10);
                    $this->SetFont('Arial', 'B', 10);
                    $this->Cell(50, 10, 'Nombre de la Obra', 1, 0, 'C', true); // Con fondo verde
                    $this->Cell(50, 10, 'Titulo del Informe', 1, 0, 'C', true); // Con fondo verde
                    $this->Cell(40, 10, 'Horas Trabajadas', 1, 0, 'C', true); // Con fondo verde
                    $this->Cell(50, 10, 'Informe', 1, 1, 'C', true); // Con fondo verde
                }

                function Footer()
                {
                    $this->SetY(-15);
                    $this->SetFont('Arial', 'I', 8);
                    $this->Cell(0, 10, 'Página ' . $this->PageNo(), 0, 0, 'C');
                }
            }

            $pdf = new PDF();
            $pdf->AddPage();
            $pdf->SetFont('Arial', '', 10);

            // Restablecer el color de fondo y texto para las celdas de datos
            $pdf->SetFillColor(255); // Color blanco
            $pdf->SetTextColor(0); // Color negro

            // Celdas de datos
            $pdf->Cell(50, 10, $row['nombre_obra'], 1, 0, 'C');
            $pdf->Cell(50, 10, $row['titulo'], 1, 0, 'C');
            $pdf->Cell(40, 10, $row['horas'], 1, 0, 'C');

            // Celda de informe (nombre del archivo)
            $pdf->Cell(50, 10, basename($row['informe']), 1, 1, 'C');

            // Output con 'D' para descargar
            $pdf->Output('D', 'Informe_Trabajo.pdf');
            exit;
        } else {
            echo "No se encontró el informe solicitado.";
        }

        $result->free();
    } else {
        echo "Parámetro de identificación de informe no válido.";
    }

    $mysqli->close();
} else {
    echo "SESION CADUCADA.";
}
?>
