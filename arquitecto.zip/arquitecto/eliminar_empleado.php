<?php
include("config.php");
session_start(); 

if(isset($_GET['id_informe']) && !empty($_GET['id_informe'])) {
    $id_informe = $_GET['id_informe'];

    $sql = "UPDATE informes_empleados SET eliminar = 'eliminado' WHERE id_informe = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $id_informe);

    if ($stmt->execute()) {
        header("Location: tabla_empleado.php?success=true");
        exit();
    } else {
        header("Location: tabla_empleado.php") . $stmt->error;
        exit();
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo "ID del informe no proporcionado o inválido.";
}
?>
